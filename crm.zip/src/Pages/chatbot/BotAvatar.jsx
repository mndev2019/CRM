const BotAvatar = () => {
  return (
    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-white shadow">
      🤖
    </div>
  );
};

export default BotAvatar;
